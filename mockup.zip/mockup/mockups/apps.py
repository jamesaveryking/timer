from django.apps import AppConfig


class MockupsConfig(AppConfig):
    name = 'mockups'
